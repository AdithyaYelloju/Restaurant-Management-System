<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div style="background-color:#e5e5e5;text-align:center;padding:10px;margin-top:0px;">Copyrights: All rights reserved by FoodCorner.com<br>Hyderabad, Telangana, India</div>
  </div>
</body>
</html>